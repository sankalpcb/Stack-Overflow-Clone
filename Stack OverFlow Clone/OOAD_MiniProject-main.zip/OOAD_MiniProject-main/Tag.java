public class Tag{
    String name;

    Tag(String name){
      this.name=name;
    }
}
