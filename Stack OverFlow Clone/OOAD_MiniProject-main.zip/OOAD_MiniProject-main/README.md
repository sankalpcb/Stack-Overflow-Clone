# StackOverflow
A stackoverflow clone built in Java

Command to run
```
javac *.java;java -cp  ".;C:\Users\tauro\Documents\packages\postgresql-42.3.3.jar" view
```